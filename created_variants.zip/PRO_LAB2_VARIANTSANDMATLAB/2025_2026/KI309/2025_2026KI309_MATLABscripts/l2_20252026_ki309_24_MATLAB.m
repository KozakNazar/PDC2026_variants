%% Варіант №24
% Обчислення виразу: x = (Y3^2*y2 - Y3*y1 - y2'*y2*Y3*y1)'*Y3^3

clear all; close all; clc;

DEFAULT_N = 2;
CHOICE_MANUAL = 1;
CHOICE_RAND = 2;

RESULT_TYPE = 'рядок';

try
%% 1. Ввід розмірності
    n = input('Введіть розмірність n: ');
    while n <= 0
        n = input('Розмірність повинна бути > 0. Введіть n: ');
    end

%% 2. Вибір способу вводу даних
    choice = 0;
    disp('Виберіть спосіб вводу даних:');
    while n != CHOICE_MANUAL && n != CHOICE_RAND
        n = input('%d - ввід з клавіатури, %d - випадкова генерація: ', CHOICE_MANUAL, CHOICE_RAND);
    end
catch
    n = DEFAULT_N;
    choice = CHOICE_RAND;
    printf('%d (значення за замовчуванням, ввід не підтримується системою виконання MATLAB-коду)\n', n);
end

%% 3. Створення матриць та векторів
if choice == 1
    %% Ввід з клавіатури
    disp('=== Ввід матриці A ===');
    A = zeros(n);
    for i = 1:n
        for j = 1:n
            A(i,j) = input(sprintf('A(%d,%d) = ', i, j));
        end
    end
    
    disp('=== Ввід матриці A1 ===');
    A1 = zeros(n);
    for i = 1:n
        for j = 1:n
            A1(i,j) = input(sprintf('A1(%d,%d) = ', i, j));
        end
    end
    
    disp('=== Ввід матриці A2 ===');
    A2 = zeros(n);
    for i = 1:n
        for j = 1:n
            A2(i,j) = input(sprintf('A2(%d,%d) = ', i, j));
        end
    end
    
    disp('=== Ввід матриці B2 ===');
    B2 = zeros(n);
    for i = 1:n
        for j = 1:n
            B2(i,j) = input(sprintf('B2(%d,%d) = ', i, j));
        end
    end
    
    disp('=== Ввід вектора b1 ===');
    b1 = zeros(n);
    for i = 1:n
        b1(i) = input(sprintf('b1(%d) = ', i));
    end

    disp('=== Ввід вектора c1 ===');
    c1 = zeros(n);
    for i = 1:n
        c1(i) = input(sprintf('c1(%d) = ', i));
    end
else
    %% Випадкова генерація
    disp('Генеруються випадкові матриці та вектори...');
    A = randi([1, 9], n, n);
    A1 = randi([1, 9], n, n)
    A2 = randi([1, 9], n, n)
    B2 = randi([1, 9], n, n)
    b1 = randi([1, 9], n, 1);
    c1 = randi([1, 9], n, 1);
    
    disp('Згенеровані матриці:');
    disp('A = '); disp(A);
    disp('A1 = '); disp(A1);
    disp('A2 = '); disp(A2);
    disp('B2 = '); disp(B2);
    disp('b1 = '); disp(b1);
    disp('c1 = '); disp(c1);
end

%% 4. Обчислення вектора b згідно формули
disp('Обчислення вектора b...');
b = zeros(n, 1);
for i = 1:n
    % Формула для b_i
    if mod(i, 2) == 0
        b(i) = 22*i; % для парних i
    else
        b(i) = 22; % для непарних i
    end
    %% b(i) = b_i_val;
end

disp('Вектор b:');
disp(b);

%% 5. Обчислення y1 = A*b
y1 = A * b;
disp('Вектор y1 = A*b:');
disp(y1);

%% 6. Обчислення y2:
disp('Обчислення y2...');
% Формула містить A1, b1, c1
y2 = A1*(b1+28*c1);

disp('Вектор y2:');
disp(y2);

%% 7. Обчислення матриці C2:
disp('Обчислення матриці C2...');
C2 = zeros(n);
for i = 1:n
    for j = 1:n
        C2(i,j) = 19/(i+2*j)^3;
    end
end

disp('Матриця C2:');
disp(C2);

%% 8. Обчислення Y3:
disp('Обчислення матриці Y3...');
Y3 = A2*B2-A2*C2;

disp('Матриця Y3:');
disp(Y3);

%% 9. Обчислення x:
disp('Обчислення x...');
x = (Y3^2*y2 - Y3*y1 - y2'*y2*Y3*y1)'*Y3^3;

[r, c] = size(x);

printf('Результат ');
if strcmp(RESULT_TYPE, 'матриця') && r == n && c == n
    printf('матриця'); 
elseif strcmp(RESULT_TYPE, 'стовпець') && r == n && c == 1
    printf('стовпець');
elseif strcmp(RESULT_TYPE, 'рядок') && r == 1 && c == n
    printf('рядок');
elseif strcmp(RESULT_TYPE, 'число') && r == 1 && c == 1
    printf('число');
else 
    printf('неочікуваний формат');
end

printf(' x:\n');
disp(x);
printf('(2025/2026 н.р., KI-309, варіант №24: x = (Y3^2*y2 - Y3*y1 - y2''*y2*Y3*y1)''*Y3^3)');
